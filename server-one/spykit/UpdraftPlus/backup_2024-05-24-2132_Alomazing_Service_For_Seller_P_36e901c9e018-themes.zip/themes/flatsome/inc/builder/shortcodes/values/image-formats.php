<?php 
return array(
     '' => 'Normal',
     'circle' => 'Circle',
     '1-1' => 'Square (1:1)',
     '16-9' => 'Widescreen (16:9)',
     '4-3' => 'Retangular (4:3)',
     '3-4' => 'Vertical (3:4)',
     '9-16' => 'Portrait (9:16)',
     '2-1' => 'Tall (2:1)',
     '1-2' => 'Wide (1:2)',
     'custom' => 'Custom',
 );